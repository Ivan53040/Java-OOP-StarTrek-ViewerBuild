[1] The game saving and loading mechanic
I ask GenAI to provide me the method to select file 
AI gave me the method of fileChooser for choosing file from the computer
and also how to select the correct .trek file by overriding the accept of File and overriding the Description
after select the file.
AI also provide me the get.SelectedFile() and getABsolutePath() method for choosing file from the computer
[2] When loading game, I failed to put the enterprise in the wanted quadrant by just changing the X and Y value of enterprise. I ask the AI and it suggest me to use the movebetweenquadrant method to place the enterprise (calculate the different between XY in save and XY in current) and move it to the desire location

[3] When building the Slider.java, I don't know how to make the slier like the assignment spec and ask AI to give me the code and make the slider show the tick and labels, so the AI give me the setPaintTicks and setPaintLabels.